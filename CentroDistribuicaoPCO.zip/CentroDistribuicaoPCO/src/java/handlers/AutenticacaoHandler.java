public class AutenticacaoHandler{




    
}