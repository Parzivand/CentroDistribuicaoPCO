package java.domain;

public class Encomenda {
    
}