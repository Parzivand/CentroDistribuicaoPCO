//import java.domain.*;
//import java.util.*;
//public  class Encomendahandler {
//    private  HashMap<String,Encomenda> Encomendas;
//    public void registar_encomenda(String estado, String referencia , Boolean prioridade, Loja  loja){
//        Encomenda e = new Encomenda(estado,referencia, prioridade,loja);
//        Encomendas.put(referencia, e);}
//
//}
