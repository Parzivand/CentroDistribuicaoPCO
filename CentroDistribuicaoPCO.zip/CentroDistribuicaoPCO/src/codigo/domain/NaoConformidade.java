package codigo.domain;

public class NaoConformidade{
    private String descricao,tipo;
    public NaoConformidade(String tipo, String descricao){
        this.tipo= tipo;
        this.descricao= descricao;
    } 
}
