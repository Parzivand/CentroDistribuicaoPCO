package codigo.domain.enums;

public enum Cargo {
    ADMINISTRADOR,
    GESTOR_lOG,
    OPERDADOR_ARM,
    OPERDADOR_SEL,
    OPERDADOR_REC, 

}
