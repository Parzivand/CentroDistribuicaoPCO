package codigo.domain.enums;
public enum EstadoExpedicao{
POR_EXPEDIR,
POR_PREPARAR,
PREPARADA,
EXPEDIDA


}