package codigo.domain.enums;

public enum TipoLocalizacao {
    DOCA,
    FRIGORIFICO,
    SOLO,
    ESTANTE
}
