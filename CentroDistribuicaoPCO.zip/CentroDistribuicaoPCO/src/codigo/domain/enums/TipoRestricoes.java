package codigo.domain.enums;

public enum TipoRestricoes {
    TEMPERATURA,
    EXIGE_VALIDADE,
    FRAGIL,
    EXPLOSIVO,
    TOXICO
}
