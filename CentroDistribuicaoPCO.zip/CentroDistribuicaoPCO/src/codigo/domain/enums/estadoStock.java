package codigo.domain.enums;
public enum estadoStock{
DISPONIVEL,
RESERVA,
QUARENTENA,

}