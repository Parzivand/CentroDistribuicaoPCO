package codigo.dto;

import java.util.List;

public class DadosIniciaisDTO {
    public List<ProdutoDTO> produtos;
    public List<UtilizadorDTO> utilizadores;
    public List<FornecedorDTO> fornecedores;
    public List<LojaDTO> lojas;
}